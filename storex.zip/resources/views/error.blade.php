@extends('layouts.main')

@section('container')
    <h1>No Permission</h1>
@endsection