<div class="text-center customgradient w-100" style="margin-top: 100px; padding: 25px">
    <h1 class="font_sen_700">StoreX</h1>
    <p class="font_sen_700">@Copyright StoreX Indonesia 2022</p>

    <div class="container">
        {{-- ig --}}
        <a href="" class="text-decoration-none text-reset font_sen_400 p-3 mx-2"><img
                src="https://i.vgy.me/emEfde.png" alt="" width="3%">&nbsp;</a>

        {{-- email --}}
        <a href="mailto:" class="text-decoration-none text-reset font_sen_400 p-3 mx-2"><img
                src="https://i.vgy.me/9MYQaA.png" alt="" width="3%">&nbsp;</a>

        {{-- tiktok --}}
        <a href="" class="text-decoration-none text-reset font_sen_400 p-3 mx-2"> <img
                src="https://i.vgy.me/oJEgdW.png" alt="" width="3%">&nbsp;</a>

        {{-- lokasi --}}
        <a href="" class="text-decoration-none text-reset font_sen_400 p-3 mx-2"><img src="https://i.vgy.me/HC8MCS.png"
                alt="" width="3%">&nbsp;</a>

        {{-- lokasi
        <a href="" class="text-decoration-none text-reset font_sen_400 p-3 mx-2"><img src="{{ asset('') }}"
                alt="" width="3%">&nbsp;</a> --}}
    </div>
</div>
